/* Simple client-side behaviour for contact */
function submitMail(e){
  e.preventDefault();
  const form = e.target;
  const name = encodeURIComponent(form.name.value || 'Visitor');
  const message = encodeURIComponent(form.message.value || '');
  const subject = encodeURIComponent('Message from Heaven113 — ' + name);
  const body = message + '%0D%0A%0D%0A--%0D%0AFrom: ' + name;
  // opens mail client
  window.location.href = 'mailto:hello@heaven113.com?subject=' + subject + '&body=' + body;
  return false;
}
